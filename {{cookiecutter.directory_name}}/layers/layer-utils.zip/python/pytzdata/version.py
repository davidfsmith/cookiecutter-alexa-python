# -*- coding: utf-8 -*-

VERSION = "2019.3"

OLSON_VERSION = "2019c"
